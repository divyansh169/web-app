import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getDatabase } from 'firebase/database';
import { getFirestore } from 'firebase/firestore'; // Add this import

const firebaseConfig = {
    apiKey: "AIzaSyAiB9wKOMeWAXbN6CBIZq6pt2c8rOuymKw",
    authDomain: "fooddelivery-d9c7a.firebaseapp.com",
    databaseURL: "https://fooddelivery-d9c7a-default-rtdb.firebaseio.com",
    projectId: "fooddelivery-d9c7a",
    storageBucket: "fooddelivery-d9c7a.appspot.com",
    messagingSenderId: "46228344043",
    appId: "1:46228344043:web:a3a3d8d5fbd6762b7782ae",
    measurementId: "G-Q7MG5YQBPS"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);
const db = getFirestore(app); // Initialize Firestore

export { app, auth, database, db }; // Export db
