import React, { useState, useEffect } from 'react';
import { getDatabase, ref, get, set, remove } from 'firebase/database';
import { getAuth } from 'firebase/auth';
import { v4 as uuidv4 } from 'uuid';  // Ensure to install uuid: npm install uuid
import '../styles/Cart.css';

const Cart = () => {
    const [cartItems, setCartItems] = useState([]);
    const [grandTotal, setGrandTotal] = useState(0);

    useEffect(() => {
        const fetchCartItems = async () => {
            const db = getDatabase();
            const auth = getAuth();
            const user = auth.currentUser;

            if (user) {
                const cartRef = ref(db, `Cart/CartItems/${user.uid}`);
                const snapshot = await get(cartRef);

                if (snapshot.exists()) {
                    const data = snapshot.val();
                    const items = Object.keys(data).map(key => ({
                        id: key,
                        ...data[key],
                        quantity: parseInt(data[key].DishQuantity, 10),
                        price: parseFloat(data[key].Price),
                        total: parseFloat(data[key].Totalprice)
                    }));
                    setCartItems(items);
                    calculateGrandTotal(items, user.uid);
                } else {
                    setCartItems([]);
                }
            }
        };

        fetchCartItems();
    }, []);

    const calculateGrandTotal = async (items, userId) => {
        const total = items.reduce((sum, item) => sum + item.total, 0);
        setGrandTotal(total);

        if (userId) {
            const db = getDatabase();
            const grandTotalRef = ref(db, `Cart/GrandTotal/${userId}`);
            await set(grandTotalRef, { GrandTotal: total });
        }
    };

    const updateQuantity = async (item, newQuantity) => {
        const db = getDatabase();
        const auth = getAuth();
        const user = auth.currentUser;

        if (user) {
            const cartRef = ref(db, `Cart/CartItems/${user.uid}/${item.id}`);
            if (newQuantity > 0) {
                const totalprice = newQuantity * item.price;

                const cartItem = {
                    DishName: item.DishName,
                    DishID: item.DishID,
                    DishQuantity: newQuantity.toString(),
                    Price: item.price.toString(),
                    Totalprice: totalprice.toString(),
                    ChefId: item.ChefId
                };

                await set(cartRef, cartItem);
                const updatedItems = cartItems.map(cartItem =>
                    cartItem.id === item.id ? { ...cartItem, quantity: newQuantity, total: totalprice } : cartItem
                );
                setCartItems(updatedItems);
                calculateGrandTotal(updatedItems, user.uid);
            } else {
                await remove(cartRef);
                const updatedItems = cartItems.filter(cartItem => cartItem.id !== item.id);
                setCartItems(updatedItems);
                calculateGrandTotal(updatedItems, user.uid);
            }
        }
    };

    const removeAllItems = async () => {
        const db = getDatabase();
        const auth = getAuth();
        const user = auth.currentUser;

        if (user) {
            const cartItemsRef = ref(db, `Cart/CartItems/${user.uid}`);
            const grandTotalRef = ref(db, `Cart/GrandTotal/${user.uid}`);
            await remove(cartItemsRef);
            await remove(grandTotalRef);
            setCartItems([]);
            setGrandTotal(0);
        }
    };

    const confirmRemoveAllItems = () => {
        const confirmed = window.confirm("Are you sure you want to remove all items from your cart?");
        if (confirmed) {
            removeAllItems();
        }
    };

    const placeOrder = async () => {
        const db = getDatabase();
        const auth = getAuth();
        const user = auth.currentUser;

        if (!user) {
            alert("You must be logged in to place an order.");
            return;
        }

        const userId = user.uid;

        // Check Chef's Stop Status
        const chefId = cartItems[0].ChefId; // Assuming all items belong to the same chef
        const chefStoppedRef = ref(db, `ChefStopped/${chefId}`);
        const chefStoppedSnapshot = await get(chefStoppedRef);

        if (chefStoppedSnapshot.exists() && chefStoppedSnapshot.val().stopped === 1) {
            alert("The chef has paused accepting orders. Please try again later.");
            return;
        }

        // Get Current Location
        navigator.geolocation.getCurrentPosition(async (position) => {
            const { latitude, longitude } = position.coords;
            const loadrr = `${latitude},${longitude}`;

            // Check if Already Ordered
            const alreadyOrderedRef = ref(db, `AlreadyOrdered/${userId}/isOrdered`);
            const alreadyOrderedSnapshot = await get(alreadyOrderedRef);

            if (alreadyOrderedSnapshot.exists() && alreadyOrderedSnapshot.val() === "true") {
                alert("You have already placed an order. Please wait until the current order is delivered.");
                return;
            }

            // Retrieve Grand Total
            const grandTotalRef = ref(db, `Cart/GrandTotal/${userId}`);
            const grandTotalSnapshot = await get(grandTotalRef);

            if (!grandTotalSnapshot.exists()) {
                alert("Error retrieving grand total.");
                return;
            }

            const grandTotalValue = grandTotalSnapshot.val().GrandTotal;

            // Fetch Customer Information
            const customerRef = ref(db, `Customer/${userId}`);
            const customerSnapshot = await get(customerRef);

            if (!customerSnapshot.exists()) {
                alert("Error retrieving customer information.");
                return;
            }

            const customerData = customerSnapshot.val();
            const firstName = customerData.FirstName;
            const lastName = customerData.LastName;
            const mobileNumber = customerData.Mobileno;
            const suburban = customerData.Suburban;
            const customerName = `${firstName} ${lastName}`;

            // Show Address and Order Method Dialog
            const localAddress = prompt("Enter your local address:");
            if (!localAddress) {
                alert("Address is required.");
                return;
            }

            const orderMethod = prompt("Enter order method (Delivery, Takeaway, Dine-In):");
            if (!orderMethod || !["Delivery", "Takeaway", "Dine-In"].includes(orderMethod)) {
                alert("Invalid order method.");
                return;
            }

            // Validate Order Conditions
            if (grandTotalValue < 50) { // Assuming 50 is the minimum order value
                alert(`Order must be above ₹50. Current total: ₹${grandTotalValue}`);
                return;
            }

            if (cartItems.length === 0) {
                alert("There should be at least 1 item in the cart.");
                return;
            }

            // Combine Address Information
            const address = `${loadrr}: ${localAddress.trim()}, ${suburban}`;

            // Create Order in Database
            const RandomUId = `${Math.floor(Date.now() / 1000)}-${uuidv4()}`;

            // Store Dishes
            const dishesData = cartItems.reduce((acc, item) => {
                acc[item.id] = {
                    ChefId: item.ChefId,
                    DishID: item.DishID,
                    DishName: item.DishName,
                    DishQuantity: item.quantity,
                    Price: item.price,
                    TotalPrice: item.total
                };
                return acc;
            }, {});

            await set(ref(db, `CustomerPendingOrders/${userId}/${RandomUId}/Dishes`), dishesData);

            // Store Other Information for CustomerPendingOrders
            const customerInfo = {
                Address: address,
                GrandTotalPrice: grandTotalValue,
                MobileNumber: mobileNumber,
                Name: customerName,
                Note: '' // Add note if required
            };

            await set(ref(db, `CustomerPendingOrders/${userId}/${RandomUId}/OtherInformation`), customerInfo);

            // Add to Chef Pending Orders
            for (const itemId in dishesData) {
                const dish = dishesData[itemId];
                const chefOrderData = {
                    ChefId: dish.ChefId,
                    DishId: dish.DishID,
                    DishName: dish.DishName,
                    DishQuantity: dish.DishQuantity,
                    Price: dish.Price,
                    RandomUID: RandomUId,
                    TotalPrice: dish.TotalPrice,
                    UserId: userId
                };

                await set(ref(db, `ChefPendingOrders/${dish.ChefId}/${RandomUId}/Dishes/${dish.DishID}`), chefOrderData);
            }

            const chefOtherInfo = {
                Address: address,
                GrandTotalPrice: grandTotalValue,
                MobileNumber: mobileNumber,
                Name: customerName,
                Note: '', // Add note if required
                RandomUID: RandomUId
            };

            await set(ref(db, `ChefPendingOrders/${chefId}/${RandomUId}/OtherInformation`), chefOtherInfo);

            // Update Already Ordered Status
            await set(alreadyOrderedRef, "true");

            alert("Order placed successfully!");

            // Clear Cart
            await removeAllItems();
        }, (error) => {
            alert(`Error getting location: ${error.message}`);
        });
    };

    return (
        <div className="cart-container">
            <h1>Your Cart</h1>
            {cartItems.length > 0 ? (
                <div>
                    {cartItems.map(item => (
                        <div key={item.id} className="cart-item">
                            <div className="cart-item-header">
                                <h2>{item.DishName}</h2>
                                <div className="quantity-controls">
                                    <button onClick={() => updateQuantity(item, item.quantity - 1)}>-</button>
                                    <span>{item.quantity}</span>
                                    <button onClick={() => updateQuantity(item, item.quantity + 1)}>+</button>
                                </div>
                            </div>
                            <div className="cart-item-details">
                                <p>Price: ₹ {item.price}</p>
                                <p>Total: ₹ {item.total}</p>
                            </div>
                        </div>
                    ))}
                    <div className="cart-footer">
                        <h2>Grand Total: ₹ {grandTotal}</h2>
                        <button onClick={confirmRemoveAllItems} className="remove-all-button">Remove All</button>
                        <button onClick={placeOrder} className="place-order-button">Place Order</button>
                    </div>
                </div>
            ) : (
                <p>Your cart is empty</p>
            )}
        </div>
    );
};

export default Cart;
